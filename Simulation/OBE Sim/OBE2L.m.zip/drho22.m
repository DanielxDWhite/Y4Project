function rh22=drho22(t,r12,r21,r22,gam,Omega_rabi,delta)
%   Detailed explanation goes here
rh22=-1i*0.5*Omega_rabi'*exp(-1i*delta*t)*r12+1i*0.5*Omega_rabi*exp(1i*delta*t)*r21-2*gam*r22;

end
