function rh12=drho12(t,r11,r12,r22,gam,Omega_rabi,delta)
%   Detailed explanation goes here
rh12=1i*0.5*Omega_rabi*exp(1i*delta*t)*(r11-r22)-gam*r12;

end
